# Blow Notes - Analisador de notas musicais a partir de áudio
__version__ = "0.1.0"
